<?php
function setTComment($db){
        if(isset($_POST['CommentSubmit'])){
            $comid=$_POST['comid'];
            $comtid=$_POST['comtid'];
            $uid=$_POST['uid'];
            $date=$_POST['date'];
            $msg=$_POST['msg'];
            $statu=$_POST['statu'];
            $q1="UPDATE complaint SET  status='$statu' WHERE complaint_id='$comid'";
            $res1=$db->query($q1);
            $msg1=$_POST['msg'];
            $q="INSERT INTO comment (comment_id,complaint_id,user_id,date,ucomment) 
            VALUES ('$comid',' $comtid','$uid','$date','$msg1')";
            $res=$db->query($q);
            /*$q2="INSERT INTO solution (comment_id,complaint_id,user_id,date,ucomment) 
            VALUES ('$comid',' $comtid','$uid','$date','$msg')";
            $res=$db->query($q2);*/
 
 
        }
     }
     ?>