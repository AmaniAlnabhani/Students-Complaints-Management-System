<?php 
include "config.php";
include "header.php";
//session_start();
 if(isset($_SESSION['user_id']))
 {
    header('Location: login.php');
 }

 
 
 
 ?>
 <!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
 
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
  </head>
  <body>
    
  <div class="container-fluid">
    <div class="row flex-nowrap">
    <?php include "sidebar.php";?>
            <div class="col py-3">  
            <?php
 
                include("config.php");
                $r1 = mysqli_query($db,"select cmp.*,u.* from complaint cmp , 
                user u where cmp.user_id=u.user_id AND u.department_id='1'  ");
                $num_rows1 = mysqli_num_rows($r1);
                $it=$num_rows1;
                
                
                $r1 = mysqli_query($db,"select cmp.*,u.* from complaint cmp , 
                user u where cmp.user_id=u.user_id AND u.department_id='2'  ");
                $num_rows1 = mysqli_num_rows($r1);
                $eng=$num_rows1;
                

                $r1 = mysqli_query($db,"select cmp.*,u.* from complaint cmp , 
                user u where cmp.user_id=u.user_id AND u.department_id='3'  ");
                $num_rows1 = mysqli_num_rows($r1);
                $bus=$num_rows1;
  

 
 
 
            ?>
  
  

  
 <head>
  
     <link href="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.css" rel="stylesheet">
     <link href="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.css" rel="stylesheet">
  
 </head>
 <body>
  <br>
 <div>
 <canvas id="myChart" >
 
  
 <?php
  
 echo "<input type='hidden' id= 'it' value = '$it' >";
 echo "<input type='hidden' id= 'eng' value = '$eng' >";
 echo "<input type='hidden' id= 'bus' value = '$bus' >";
 ?>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.bundle.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.bundle.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js"></script>
  
  
 <script>
     var it = document.getElementById("it").value;
     var eng = document.getElementById("eng").value;
     var bus = document.getElementById("bus").value;
     window.onload = function()
     {
         var randomScalingFactor = function() {
             return Math.round(Math.random());
         };
         var config = {
             type: 'bar',
             data: {
                 borderColor : "#fffff",
                 datasets: [{
                     data: [
                         it,
                         eng,
                         bus,
                         
                     ],
                     borderColor : "#fff",
                     borderWidth : "3",
                     hoverBorderColor : "#000",
  
                     label: 'Complaint ',
  
                     backgroundColor: [
                         "#0190ff",
                         "#56d798",
                         "#ff8397",
                         "#6970d5",
                         "#f312cb",
                         "#ff0060",
                         "#ffe400"
  
                     ]
                    
                 }],
  
                 labels: [
                     'IT',
                     'ENG',
                     'BUS',
                 ]
             },
  
             options: {
                 responsive: true
  
             }
         };
         var ctx = document.getElementById('myChart').getContext('2d');
         window.myPie = new Chart(ctx, config);
  
  
     };
 </script>
 </canvas></div>



             <div>           







        </div>
    </div>









            </div>    
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
  </body>
</html>
<?php 
include "footer.php";?>
