<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    
  </head>
  <body>
            <div class="col-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-dark " >
        
             <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                <p   class="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-white text-decoration-none">
                

               <?php
               include "config.php";
               session_start();
               //if(isset($_SESSION['user_id']))
               //{
                //  header('Location: login.php');
               //}
               $m=$_SESSION['type'];
               
               if($m == "S"){
               ?>
                <h7><?php echo $_SESSION['user_name']?></h7<br>
                <br>
                <br>
                <a href="index.php"> Home</a><br><br>
               <a href="newComplaint.php"> New Complaint</a><br><br>
               <a href="showcomplaint.php">  Complaints log</a><br><br>
               <a href="logout.php"> logout</a>
               <?php 
               }else if($m == "hos"){
               ?>
                <h4><?php echo $_SESSION['user_name']?></h4><br>
               
              <a href="index.php">Home</a>
              <br>
              <a href="hos.php">show complaint</a><br>
              <a href="logout.php">logout</a>
               
              

               <?php } else if($m =="hod"){?>
                <h4><?php echo $_SESSION['user_name']?></h4><br>
               
              <a href="index.php">Home</a>
              <br>
              <a href="hodComp.php">show complaint</a><br>
              <a href="logout.php">logout</a>


              <?php } else if($m =="teacher"){?>
                <h4><?php echo $_SESSION['user_name']?></h4><br>
               
              <a href="index.php">Home</a>
              <br>
              <a href="TComplints.php">show complaints</a><br>
              <a href="logout.php">logout</a>
              

              <?php }else if($m == "dean"){?>
                <h4><?php echo $_SESSION['user_name']?></h4><br>
                <a href="index.php">Home</a>
              <br>
              <a href="report2.php">report base on Department</a><br>
              <a href="report.php">report base on status</a><br>
              <a href="Report1.php">report base on types</a><br>
              <a href="logout.php">logout</a>
			  
			  
			    <?php }else if($m == "admin"){?>
                <h4><?php echo $_SESSION['user_name']?></h4><br>
                <a href="index.php">Home</a>
              <br>
              <a href="Semester.php">Add Semester </a><br>
			     <a href="addCourse.php">Add Course </a><br>
			   <a href="Register.php">Create user account</a><br>
              <a href="logout.php">logout</a>
              <?php }?>
			   
               
               
               
               
               
               
               
  

                
              </div>
            
            </div>
               
               
        
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>