<?php
    function setComments($db){
       if(isset($_POST['CommentSubmit'])){
           $comid=$_POST['comid'];
           $comtid=$_POST['comtid'];
           $uid=$_POST['uid'];
           $date=$_POST['date'];
           $msg=$_POST['msg'];
           $q="INSERT INTO comment (comment_id,complaint_id,user_id,date,ucomment) 
           VALUES ('$comid',' $comtid','$uid','$date','$msg')";
           $res=$db->query($q);
          

       }
       
      

    }
    
    function setCommenthos($db){
        if(isset($_POST['update'])){
            $soluid=$_POST['soluid'];
            $solutext=$_POST['solutext'];
            $comid=$_POST['comid'];
            $uid=$_POST['uid'];
            $date=$_POST['date'];
            $statu=$_POST['statu'];
            $q1="UPDATE complaint SET  status='$statu' WHERE complaint_id='$comid'";
            $res1=$db->query($q1);
            $q="INSERT INTO solution (solution_id,solution_text,complaint_id,user_id,date) 
            VALUES ('$soluid',' $solutext','$comid','$uid','$date')";
            $res=$db->query($q);
            
 
 
        }
     }
    
     ?>