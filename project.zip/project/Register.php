<?php 
include "config.php";
include "header.php";
//session_start();
 if(isset($_SESSION['user_id']))
 {
    header('Location: login.php');
 }
  
 if(  empty($_POST['uid'])&& empty($_POST['pass']) && empty($_POST['num']) && empty($_POST['dep']) && empty($_POST['ad']) && empty($_POST['em']) && empty($_POST['role'])    ){ $errors[]="Please chack "; }	

 if(isset($_POST['submit']))
  { 
   $id=$_POST['uid'];
   $pass=$_POST['pass'];
   $name=$_POST['num'];
   $dep=$_POST['dep'];
   $ad=$_POST['ad'];
   $em=$_POST['em'];
   $role=$_POST['role'];
   $code = rand(9999, 1111);
    $query=mysqli_query($db,"insert into user(user_id,password,user_name,department_id,advisor,email,type,code) values('$id',
   '$pass','$name','$dep','$ad','$em','$role','$code')")or die(mysqli_error($db));
  
   

   if( $query  )
      {
      echo "<script>alert('Successfully Registered. ');</script>";
      //header('location:Register.php');
      }
      else{ echo"erorr in connection";}
    

   
   }




















 ?>
 <!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
  </head>
  <body>
    
  <div class="container-fluid">
    <div class="row flex-nowrap">
    <?php include "sidebar.php";?>
            <div class="col py-3">  
            <form action="Register.php" method="POST" >
          <div class="mb-3">
          <label class="form-label">User ID</label>
          <input type="text" class="form-control" name="uid" required >
          </div>
          <div class="mb-3">
          <label class="form-label">Password</label>
          <input type="password" class="form-control" name="pass" >
          </div>
          <div class="mb-3">
          <label class="form-label">Name</label>
          <input type="text" class="form-control" name="num" >
          </div>
          <div>
          <label class="form-label">Department</label><br/>
          <input type="radio"  value="1" name="dep"  >IT &nbsp; &nbsp;  &nbsp; &nbsp; 
          <input type="radio"    value="3" name="dep" checked > Bus &nbsp; &nbsp;  &nbsp; &nbsp; 
          <input type="radio"  value="2" name="dep"  >ENG &nbsp; &nbsp;  &nbsp; &nbsp; 
          </div></br>
          <div class="mb-3">
          <label class="form-label">Advisor</label>
          <input type="text" class="form-control" name="ad" >
          </div>
          <div class="mb-3">
          <label class="form-label">Email</label>
          <input type="text" class="form-control" name="em" >
          </div>
          <div>
          <label class="form-label">Type</label><br/>
          <input type="radio"  value="1" name="role"  >Student &nbsp; &nbsp;  &nbsp; &nbsp; 
          <input type="radio"  value="5" name="role"  >Teacher &nbsp; &nbsp;  &nbsp; &nbsp; 
          <input type="radio"    value="2" name="role" checked > HOS&nbsp; &nbsp;  &nbsp; &nbsp; 
          <input type="radio"  value="3" name="role"  >HOD &nbsp; &nbsp;  &nbsp; &nbsp; 
          <input type="radio"  value="4" name="role"  >Dean &nbsp; &nbsp;  &nbsp; &nbsp; 
          <input type="radio"  value="6" name="role"  >Admin &nbsp; &nbsp;  &nbsp; &nbsp; 
         </br>
          </div>
          </br>
          <input class="btn btn-primary" type="submit" name="submit" value="submit">
       </form>



            </div>    </div>  </div>  
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
  </body>
</html>
<?php 
include "footer.php";?>
