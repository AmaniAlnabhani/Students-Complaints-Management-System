<?php 
include "config.php";
include "header.php";
 if(isset($_SESSION['user_id']))
 {
    header('Location: login.php');
 }
 
 ?>
 <!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
  </head>
  <body>
    
  <div class="container-fluid">
    <div class="row flex-nowrap">
    <?php include "sidebar.php";?>
    <div style="margin-left:50px;">
    <h3>Change Complaints Status</h3>
  <form name="details" id="details" method="post"> 
<table class="table table-bordered table-hover table-stripped" style="table-layout" fixed;>
<?php
include "config.php";
//echo print_r ($_GET);
$q1="SELECT
u.user_id,u.user_name, u.email,
u.advisor, c.complaint_id, c.details
FROM user u
JOIN complaint c
WHERE u.user_id=c.user_id AND u.user_id='".$_GET['sid']."' AND c.complaint_id='".$_GET['cid']."'" ;
/*$q="select cmp.*,u.* from complaint cmp , user u where cmp.user_id=u.user_id"; */  
//echo $q1;
$res=mysqli_query($db,$q1);
while($row=mysqli_fetch_array($res))
{
?>
<tr height="30">
<td><b>Student ID:</b></td>
<td><?php echo ($row['user_id']); ?></td>
</tr>

<tr height="30">
<td><b>Student Name:</b></td>
<td><?php echo ($row['user_name']); ?></td>
</tr>
<tr height="30">
<td><b>Student Email:</b></td>
<td><?php echo ($row['email']); ?></td>
</tr>
<tr height="30">
<td><b>Student Advisor:</b></td>
<td><?php echo ($row['advisor']); ?></td>
</tr>
<tr height="30">
<td><b>complaint ID:</b></td>
<td><?php echo ($row['complaint_id']); ?></td>
</tr>
<tr height="30">
<td><b>complaint Details:</b></td>
<td><?php echo ($row['details']); ?></td>
</tr>
    <?php } ?> 
</table>
</form>
<br>
 <?php
include 'config.php';
include 'insertlog.php';
include 'usercomments.php';
$res=mysqli_query($db,$q1);
while($row=mysqli_fetch_array($res))
{
  echo"<b><h4>Change Complaint status:</h4></b>
<form method='POST' action='".setCommenthos($db)."'>
<input type='hidden' name='soluid' value='". $id = rand(9999, 1111)."'>
<textarea name='solutext' width=900px height='80px' ></textarea>
<input type='hidden' name='comid' value='".$row['complaint_id']."'>
<input type='hidden' name='uid' value='".$_SESSION['user_id']."'>
<input type='hidden' name='date' value='".date('Y-m-d H:i:s')."'> <br>
<button type='submit' name='update' class='btn btn-outline-success'>Send Solution</button>
 </form><br>";
  echo"  <b><h4>Complaint status</h4></b>
<form  method='post' action='".setnewStatu($db)."'> 
<input type='hidden' name='log_id' value='".$id = rand(9999, 1111)."'>
<table border=2><tr><td> 
<select name='statu'>
<option value=x>Choose status</option>
<option value='NEW'>NEW</option>
<option value='INProgress'>IN Progress</option>
<option value='Closed'>Closed</option>
<option value='ForwardToTeacher'>Forward to Techer</option>
<option value='EsclateToHOD'>Esclate to HOD</option></select>
</table></TR></td><br>
<input type='hidden' name='time' value='".date('H:i:s')."'> 
<input type='hidden' name='date' value='".date('d/m/Y')."'>
<input type='hidden' name='status' value='status'>  
<input type='hidden' name='uid' value='".$_SESSION['user_id']."'>
<input type='hidden' name='comid' value='".$row['complaint_id']."'>
<button type='submit' name='insert' class='btn btn-primary btn-sm'>Update</button><BR><BR>
</form>";
}
?>
  </div>

    


</div>
</div>
</div>




    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
  </body>
</html>
<?php include "footer.php";?>