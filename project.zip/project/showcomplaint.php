<?php 
include "config.php";
include "header.php";

 if(isset($_SESSION['user_id']))
 {
    header('Location: login.php');
 }
 else{

  if(isset($_POST['submit']))
{
  
$r=$_SESSION['user_id'];
$sql=mysqli_query($db,"select password from user where password='".$_POST['password']."' and user_id='".$r."'");
$num=mysqli_fetch_array($sql);
if($num>0)
{
 $con=mysqli_query($db,"update user set password='".($_POST['newpassword'])."' where user_id='".$_SESSION['user_id']."'");
$successmsg="Password Changed Successfully !!";
}
else
{
$errormsg="Old Password not match !!";
}
}


 }
 ?>
 <!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
  </head>
  <body>
    
  <div class="container-fluid">
    <div class="row flex-nowrap">
    <?php include "sidebar.php";?>
<div class="col py-3">
<div>
    <div class="table-responsive">
    <div class="table-scroll">
      <table class="table table-bordered table-hover table-stripped" style="table-layout" fixed;>
        <thead>
          <tr>
            <th>Complaint</th>
            <th>User ID</th>
            <th>Details</th>
            <th>Status</th>
            <th>solution</th>
          </tr>
        </thead>
        <?php
           include "config.php";
           include 'usercomments.php';
           $m=$_SESSION['user_id'];
          $q="select * from complaint where user_id='$m'";
          $res=mysqli_query($db,$q);
          while ($rows=mysqli_fetch_array($res))
          {
            $complaint_id=$rows['complaint_id'];
            $user_id=$rows['user_id'];
            $details=$rows['details'];
            $status=$rows['status'];
          $q1="select * from solution where complaint_id='$complaint_id'";
          $res1=mysqli_query($db,$q1);
          while ($rows=mysqli_fetch_array($res1))
          {
            $solution_text=$rows['solution_text'];
            
          }
          ?>
        <tr>
        <td><?php echo $complaint_id  ?></td>
        <td><?php echo $user_id ?></td>
        <td><?php echo $details ?></td>
        <td><?php echo $status ?></td>
        <td><?php echo $solution_text ?>
        <?php
echo "<form method='POST' action='".setComments($db)."'>
<input type='hidden' name='comid' value='".$id = rand(9999, 1111)."'>
<input type='hidden' name='comtid' value='".$complaint_id."'>
  <input type='hidden' name='uid' value='".$_SESSION['user_id']."'>
  <input type='hidden' name='date' value='".date('Y-m-d H:i:s')."'> 
  <textarea name='msg' width=900px height='80px' placeholder='Enter your Comment' ></textarea><br>
  <button type='submit'name='CommentSubmit'>Send Comment</button><br>
 </form>";?>
      </td>

      </tr>

<?php }?>
<?php
echo "<script>alert('Successfully Add Your Comment');</script>";
?>
</table>
</div>
</div>
</div>
</div>
</div>

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
  </body>
</html>
<?php 
include "footer.php";?>