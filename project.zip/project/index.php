<?php 
include "config.php";
include "header.php";
 //session_start();

 if(isset($_SESSION['user_id']))
 {
    header('Location: login.php');
 }
 else{

  if(isset($_POST['submit']))
{ session_start();
 
 $sql=mysqli_query($db,"select password from user where password='".$_POST['password']."' and user_id='".$_SESSION['user_id']."'");
 $num=mysqli_fetch_array($sql);
if($num>0)
{
 $db=mysqli_query($db,"update user set password='".($_POST['newpassword'])."' where user_id='".$_SESSION['user_id']."'");
 
 echo "
<script>
alert('Password Changed Successfully !!');
 window.location.href = 'index.php';

</script>
";
}
else
{
  echo "
<script>
alert('Old Password not match !!');
 window.location.href = 'index.php';
 </script>";
 
}
}


 }
 ?>
 <!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
  </head>
  <body>
  <div class="container-fluid">
    <div class="row flex-nowrap">
        <?php include "sidebar.php";?>
          <div class="col py-3">
           <div>
           <form class="form-horizontal style-form" method="POST" action="index.php">

                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Current Password</label>
                              <div class="col-sm-10">
                                  <input type="password" name="password" required="required" class="form-control">
                              </div>
                          </div>


<div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">New Password</label>
                              <div class="col-sm-10">
                                  <input type="password" name="newpassword" required="required" class="form-control">
                              </div>
                          </div>

<div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Confirm Password</label>
                              <div class="col-sm-10">
                                  <input type="password" name="confirmpassword" required="required" class="form-control">
                              </div>
                          </div>
                          <div class="form-group">
                           <div class="col-sm-10" style="padding-left:25% ">
<button type="submit" name="submit" class="btn btn-primary">Submit</button>
</div>
</div>

                          </form>
           </div>
        </div>
        </div>
        
    </div>
</div>

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
  </body>
</html>
<?php 
include "footer.php";?>