<?php
include"config.php";


if(isset($_POST['submit'])){

    $uname = mysqli_real_escape_string($db,$_POST['username']);
    $password = mysqli_real_escape_string($db,$_POST['password']);
    $number    = preg_match("/^[0-9]{8}$/", $password);
    if( !$number || !strlen($password) < 8) {
        echo 'Password should be 8 characters in length and only number <br>';
        
    }
    if(!preg_match("/^[a-z][1-9]{9}$/",$uname)){  echo 'username  should be 8 characters include characters & number <br>';}
   
    if ($uname != "" && $password != ""){
        

        $sql_query = "select * from user where user_id='".$uname."' and password='".$password."'";
        $result = mysqli_query($db,$sql_query);
       
        $row = mysqli_fetch_array($result);
        
        //$count = $row['user_id'];

        if( $row > 0){
            if(!empty($_POST["remember"])) {
             
                setcookie ("user_id",$uname,time()+ 3600);
                setcookie ("password",$password,time()+ 3600);
            }
            else{
                setcookie("username","");
                setcookie("password","");


            }
            session_start();
            $_SESSION['user_id']=$row["user_id"];
	        $_SESSION['user_name']= $row["user_name"];
	        $_SESSION['type']=$row["type"];
            $_SESSION['department_id']=$row["department_id"];
            $_SESSION['advisor']=$row["advisor"];
            //$_SESSION['$usernam'] = $username;
            header('Location: index.php');
        }else{
            echo "Invalid username and password";
        }
     
       
        








    }

}
?>








<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Login</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<style>
.login-form {
    width: 340px;
    margin: 50px auto;
  	font-size: 15px;
}
.login-form form {
    margin-bottom: 15px;
    background: #f7f7f7;
    box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
    padding: 30px;
}
.login-form h2 {
    margin: 0 0 15px;
}
.form-control, .btn {
    min-height: 38px;
    border-radius: 2px;
}
.btn {        
    font-size: 15px;
    font-weight: bold;
}
</style>
</head>
<body>
<div class="login-form">
    <form action="login.php" method="POST">
        <h2 class="text-center">Log in</h2>       
        <div class="form-group">
            <input type="text" name="username" class="form-control"  
			value="<?php if(isset($_COOKIE["user_id"])) { echo $_COOKIE["user_id"]; } ?>" 
			placeholder="Username" required="required">
        </div>
        <div class="form-group">
            <input type="password" name="password" class="form-control" placeholder="Password" 
			value="<?php if(isset($_COOKIE["password"])) { echo $_COOKIE["password"]; } ?>" 
			required="required">
        </div>
        <div class="form-group">
            <button type="submit" name="submit" class="btn btn-primary btn-block">Log in</button>
        </div>
        <div class="clearfix">
            <label class="float-left form-check-label"><input type="checkbox" name='remember'> Remember me</label>
            <a href="forgotPassword.php" class="float-right">Forgot Password?</a>
        </div>        
    </form>
   
</div>
</body>
</html>
