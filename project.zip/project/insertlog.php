
<?php
function setnewStatu($db){
        if(isset($_POST['insert'])){
            $log_id=$_POST['log_id'];
            $statu=$_POST['statu'];
            $time=$_POST['time'];
            $date=$_POST['date'];
            $uid=$_POST['uid'];
            $comid=$_POST['comid'];
            $q="INSERT INTO log (log_id,status,time,date,user_id,complaint_id) 
            VALUES ('$log_id',' $statu','$time','$date','$uid','$comid')";
            $res=$db->query($q);
            $q1="UPDATE complaint SET  status='$statu' WHERE complaint_id='$comid'";
           $res1=$db->query($q1);
           //header('Location: hos.php');
 
 
        }
     }
     
     ?>