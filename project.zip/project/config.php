<?php
$mysql_hostname = "localhost";
$mysql_user = "group44";
$mysql_password = "601476";
$mysql_database = "dbgroup44";
$db= mysqli_connect($mysql_hostname, $mysql_user, $mysql_password, $mysql_database) or die("Could not connect database");



?>