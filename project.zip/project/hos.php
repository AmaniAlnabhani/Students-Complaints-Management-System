<?php 
include "config.php";
include "header.php";
 if(isset($_SESSION['user_id']))
 {
    header('Location: login.php');
 }
 
 ?>
 <!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
  </head>
  <body>
    
  <div class="container-fluid">
    <div class="row flex-nowrap">
    <?php include "sidebar.php";?>
    <div class="module">
	<div class="module-head">
	<h3>Complaint Details</h3>
	</div>
	<div class="module-body table">
    <table cellpadding="0" cellspacing="0"  class="datatable-1 table table-bordered table-striped	 display" fixed;>

<?php 
$query=mysqli_query($db,"select cmp.*,u.* from complaint cmp , 
user u where cmp.user_id=u.user_id AND u.department_id='".$_SESSION['department_id']."' AND cmp.status='NEW' ");
while($row=mysqli_fetch_array($query))
{

?>									
<tr>
<td><b>complaint ID </b></td>
	<td><?php echo ($row['complaint_id']);?></td>	
    <td><b>Category </b></td>
	<td><?php echo ($row['ctype']);?></td> 
	
</tr>
<tr>
    <td><b>Student Name </b></td>
	<td><?php echo ($row['user_name']);?></td> 
    <td><b>Student Advisor </b></td>
	<td><?php echo ($row['advisor']);?></td>
	<td><b>Evidence ID: </b></td>
	<td colspan="5"> <?php echo ($row['evid_id']);?></td>  
	 
    
</tr>
<tr>
<td><b>Complaint Details </b></td>
<td colspan="5"> <?php echo ($row['details']);?></td>
</tr>

<tr>
<td><b>File(if any) </b></td>
<td colspan="5"> <?php $cfile=$row['evid_id'];
if($cfile=="" || $cfile=="NULL")
{
  echo "File NA";
}
else{?>
<?php $query2=mysqli_query($db,"select file_name from evidence where evid_id=$cfile");
$row2=mysqli_fetch_array($query2) ?>





<a  download href="<?php echo ($row2['file_name']);?>"> View File</a>
<?php } ?></td>
</tr>
<tr>
<td><b>Final Status</b></td>
<td colspan="5"><?php if($row['status']=="")
{ echo "Not Process Yet";
} 
else {echo ($row['status']);}?></td>
</tr>
<tr>
<td><b>Action</b></td>
<td> 
	<?php if($row['status']=="closed"){}
	 else {?>
			<a href="ChangStaut.php" title="Update Complaint"></a>
      <a href="ChangStaut.php?sid=<?php echo $row['user_id']?>&cid=<?php echo $row['complaint_id']?>">Change Status</a>
    </td>

			<?php } ?></td>
			<td> 
			<a href="forwardT.php" title="Forward Complaint"></a>
      <a href="forwardT.php?sid=<?php echo $row['user_id']?>&cid=<?php echo $row['complaint_id']?>">Forward To Lecturer</a>
    </td>

			<td> 
			<a href="esclateHod.php" title="Esclate Complaint"></a>
      <a href="esclateHod.php?sid=<?php echo $row['user_id']?>&cid=<?php echo $row['complaint_id']?>">Esclate TO HOD</a>
    </td>
		
			<td> 
			<a href="userDetail.php" title="View Student Dtails"></a>
			<a href="userDetail.php?sid=<?php echo $row['user_id']?>">View Student Detials</a>
		</td>
		</tr>
			<?php  } ?>
</table>
<br>
</div>
</div>						
</div>
</div>
</div>
</div>
</div>




    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
  </body>
</html>
<?php include "footer.php";?>