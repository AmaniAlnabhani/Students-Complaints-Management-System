<?php
include_once("config.php");
	
if(isset($_POST["export_csv_data"])) {
    $query = "SELECT * FROM complaint ";
$result = mysqli_query($db, $query) or die("database error:". mysqli_error($conn));
$records = array();
while( $rows = mysqli_fetch_assoc($result) ) {
	$records[] = $rows;
}
    
	$csv_file = "complaint_csv_export_".date('Ymd') . ".csv";			
	header("Content-Type: text/csv");
	header("Content-Disposition: attachment; filename=\"$csv_file\"");	
	$fh = fopen( 'php://output', 'w' );
	$is_coloumn = true;
	if(!empty($records)) {
	  foreach($records as $record) {
		if($is_coloumn) {		  	  
		  fputcsv($fh, array_keys($record));
		  $is_coloumn = false;
		}		
		fputcsv($fh, array_values($record));
	  }
	   fclose($fh);
	}
	exit;  
}
///////////////
if(isset($_POST["exportNonAcadmic_csv_data"])) {
 $query = "SELECT * FROM complaint where ctype='Non-Academic' ";
$result = mysqli_query($db, $query) or die("database error:". mysqli_error($conn));
$records = array();
while( $rows = mysqli_fetch_assoc($result) ) {
	$records[] = $rows;
}
    
	$csv_file = "complaint_csv_export_".date('Ymd') . ".csv";			
	header("Content-Type: text/csv");
	header("Content-Disposition: attachment; filename=\"$csv_file\"");	
	$fh = fopen( 'php://output', 'w' );
	$is_coloumn = true;
	if(!empty($records)) {
	  foreach($records as $record) {
		if($is_coloumn) {		  	  
		  fputcsv($fh, array_keys($record));
		  $is_coloumn = false;
		}		
		fputcsv($fh, array_values($record));
	  }
	   fclose($fh);
	}
	exit;  
}
///////////////
if(isset($_POST["exportAcadmic_csv_data"])) {
    $query = "SELECT * FROM complaint where ctype='Academic' ";
   $result = mysqli_query($db, $query) or die("database error:". mysqli_error($conn));
   $records = array();
   while( $rows = mysqli_fetch_assoc($result) ) {
       $records[] = $rows;
   }
       
       $csv_file = "complaint_csv_export_".date('Ymd') . ".csv";			
       header("Content-Type: text/csv");
       header("Content-Disposition: attachment; filename=\"$csv_file\"");	
       $fh = fopen( 'php://output', 'w' );
       $is_coloumn = true;
       if(!empty($records)) {
         foreach($records as $record) {
           if($is_coloumn) {		  	  
             fputcsv($fh, array_keys($record));
             $is_coloumn = false;
           }		
           fputcsv($fh, array_values($record));
         }
          fclose($fh);
       }
       exit;  
   }
   ///////////////



?>