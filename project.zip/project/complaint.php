<?php 
 include('config.php');
 
 if(isset($_SESSION['user_id']))
   {
    header('Location: login.php');
   }
  

   if(isset($_POST['submit']))
   { 
      session_start();
      $details=$_POST['details'];
      //$f=$_POST['file'];
      $t=$_POST['acct'];
      $type=$_POST['type'];
      $mn=$_SESSION['user_id'];
      
      
       //////////////complaint id////////
      $id = rand(9999, 1111);
      
      
       date_default_timezone_set('Asia/Muscat');
       $date = date('m/d/Y');
       $time= date('h:i:s a', time());
       $s="NEW";
      ///////insert in log table/////////
       $query1=mysqli_query($db,"insert into log(status,time,date,user_id,complaint_id) values('$s',
       '$time','$date','$mn','$id')")or die(mysqli_error($db));
     ///////////insert in evidence table/////////////
     //echo "<pre>";print_r($_POST);echo "</pre>";
     //echo "<pre>";print_r($_FILES);echo "</pre>";
     ////upload file/////////
     $myfile=  $_FILES['dfile'];
     copy($myfile['tmp_name'],$myfile['name']);
          ///////////insert in evidence table/////////////
          $ev= rand(9999,1111);
          $name=$myfile['name'];
          $tt=$myfile['type'];
          $size=$myfile['size'];
          $time= date('h:i:s a', time());

     $query2=mysqli_query($db,"insert into evidence(evid_id,file_name,type,size,time,complaint_id) values('$ev','$name',
      '$tt','$size','$time','$id')")or die(mysqli_error($db));
     ///////////insert in complaint table/////////
     $query3=mysqli_query($db,"insert into complaint(complaint_id,details,ctype,status,user_id,cours_id,evid_id,comment_id) values('$id','$_POST[details]',
      '$type','$s','$mn','$t','$ev','0')")or die(mysqli_error($db));
     

      


      if( $query1  && $query3&& $query2)
      {
      echo "<script>alert('Successfully Registered. ');</script>";
      header('location:newComplaint.php');
      }
      else{ echo"erorr in connection";}
    

    
      

  
   } else{echo"error";} 
     




 







   

?>